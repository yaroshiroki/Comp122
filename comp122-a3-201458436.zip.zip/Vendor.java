//importing.
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
public class Vendor {
    //defining the method itemsFromFile, which will open the text file.
    public static Item[] itemsFromFile(String filename) {
        //declaring variables.
        File fileHandler;
        Scanner s;
        //making an arrayList, in order to convert back to array at the end - using hint.
        ArrayList<String> items = new ArrayList<>();
        //accessing the file.
        String fileName = filename;
        fileHandler = new File(fileName);
        //try catch definition.
        try {
            //declaring the fileHandler, using the scanner.
            s = new Scanner(fileHandler);
            //while the file has a NextLine,
            while (s.hasNextLine()) {
                Double num = s.nextDouble();
                if (s.hasNextLine())
                    //add the line to the string.
                    items.add(s.nextLine());
            }
        //catch exception and message.
        } catch (FileNotFoundException fnfe){
            System.out.println(fnfe + "file not found");
        }
        //return and convert the arrayList into an array.
        return items.toArray(new Item[items.size()]);
    }
}
