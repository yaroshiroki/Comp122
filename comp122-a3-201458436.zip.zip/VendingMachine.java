//importing.
import java.util.ArrayList;
import java.text.DecimalFormat;
public class VendingMachine {
    //declaring variables.
    private Item[] availableItems;
    ArrayList<Item> soldItems = new ArrayList<>();
    public double cassette;
    //instantiate VendingMachine with items.
    public VendingMachine(Item[] items) {
        this.availableItems = items;
    }
    //define method getCassette to just return cassette.
    public double getCassette() { return cassette; }
    //define method returnCoins, to simply return cassetteVal = 0.
    public double returnCoins() {
        double cassetteVal = 0;
        return cassetteVal;
    }
    //boolean method, which returns whether the coin which you entered is valid or not.
    private boolean isAcceptableCurrency(double currency) {
        //an array of currencies which are acceptable.
        double[] acceptableCurrency = new double[]{
                0.01,
                0.02,
                0.05,
                0.1,
                0.2,
                0.5,
                1,
                2};
        //check against the array of acceptable currencies to see whether the coin is valid.
        for (var valToCheck : acceptableCurrency) {
            if ((valToCheck == currency)) {
                return true;
            }
        }
        return false;
    }
    //check whether the price is equal to cassette value.
    private boolean isMoreThan(Item item) { return (item.getPrice() > this.cassette); }
    private boolean isLessThan(Item item) { return (item.getPrice() < this.cassette); }
    //check whether an item is sold.
    private boolean isSold(Item item) {
        for (var soldItem : this.soldItems) {
            if ((soldItem == item)) {
                return true;
            }
        }
        return false;
    }
    //formats how patterns are to be outputted.
    public String display() {
        DecimalFormat decimalFormat = new DecimalFormat("#.###");
        return("$" + decimalFormat.format(cassette));
    }
    //method which sells the i'th item.
    public Item getItem(int i) throws CassetteException, ItemSoldException {
        //checks if i is not a valid array index, throw an IllegalArgumentException.
        if (((i < 0) || (i > this.availableItems.length))) {
            throw new IllegalArgumentException(i + " is not a valid item.");
        }
        //checks if item is sold and throws CassetteException.
        var item = availableItems[i];
        if (this.isSold(item)) {
            throw new CassetteException(item.getDescription() + " has been sold.");
        }
        //check if price is less than cassette and acts accordingly.
        if (this.isLessThan(item)) {
            cassette = (cassette - item.getPrice());
        }
        //checks if price is more than cassette and throws ItemSoldException.
        if (this.isMoreThan(item)) {
            throw new ItemSoldException(item.getDescription() + " price is more than defined value.");
        }
        //adds item to sold items and returns item.
        this.soldItems.add(item);
        return item;
    }
    //defining method insertCoin, which adds the value of parameter to cassette.
    public void insertCoin(double coin) {
        //checks if coin is valid and if not, throw IllegalArgumentException.
        if (this.isAcceptableCurrency(coin) == false) {
            throw new IllegalArgumentException(coin + " is not a valid coin.");
        }
        cassette += (cassette + coin);
    }
}