public class CassetteException extends Exception{
    public CassetteException() {

    }
    public CassetteException(String message) {
        super(message);
    }
    public CassetteException(String message, Exception innerException) {
        super(message, innerException);
    }
}
