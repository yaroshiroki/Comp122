public class ItemSoldException extends Exception{
    public ItemSoldException() {

    }
    public ItemSoldException(String message) {
        super(message);
    }
    public ItemSoldException(String message, Exception innerException) {
        super(message, innerException);
    }
}
