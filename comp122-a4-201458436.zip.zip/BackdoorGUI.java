/*

Name: Yaroslav Shiroki
Student ID: 201458436
University email address: Y.Shiroki@student.liverpool.ac.uk

*/
/**
 * @author Yaroslav Shiroki Y.Shiroki@student.liverpool.ac.uk

BackdoorGUI class that uses the methods from the
Cipher interface.
 */
import javax.swing.*;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class BackdoorGUI extends JFrame {
    //Label to identify the text field for the encryptedText.
    private JLabel encryptedTextLabel;
    //TextField where to input the encryptedText.
    private final JTextField encryptedTextField;
    //Label to identify the text field for the decrypted string.
    private JLabel decryptedTextLabel;
    //TextField where the shifted string will be output.
    private JTextField decryptedTextField;
    //Button to start the decryption of the string using the Brutus function.
    private JButton decryptionButton;

    /**
     * Takes a string encryptedTextField and decryptionButton click as parameters and decrypts the string by the key by the
     * required number of shifts using the Brutus function. Also formats most of the basic GUI functions for the frame and the layout of the frame.
     * @param encryptedTextField Input string to be shifted
     * @param decryptionButton click
     * @return Returns the rotated text string (decryptedTextField)
     */
    public BackdoorGUI() {
        //turn off the default layout manager.
        setLayout(null);

        //create components.
        //encrypted text before decryption.
        encryptedTextLabel = new JLabel("Enter some text: ");
        encryptedTextField = new JTextField(100);
        encryptedTextField.setToolTipText("Enter some text here to encrypt or decrypt ");

        //decryption button.
        decryptionButton = new JButton("Press to decrypt");
        decryptionButton.setEnabled(true);
        decryptionButton.addActionListener(new ActionListener() {
            /**
             * Takes a string encryptedTextField as parameters and decrypts the string by the key by the required number of shifts
             * when the button is pressed using the Brutus function.
             * @param encryptedTextField Input string to be shifted
             * @param decryptionButton click
             * @return Returns the rotated text string (decryptedTextField)
             */
            public void actionPerformed(ActionEvent e) {
                try {
                    /**
                     * instantiating the Caesar class using  new Caesar(key)
                     */
                    Cipher b = new Brutus();
                    //decrypting the text using the Brutus function.
                    String textToDecrypt = b.decrypt(encryptedTextField.getText());
                    //output the decrypted text in the required format.
                    decryptedTextField.setText("Decrypted text:  " + textToDecrypt);
                }
                //recycled code from CryptoGUI.
                catch (NumberFormatException e1) {
                    JOptionPane.showMessageDialog(null, "Invalid input");
                    encryptedTextField.setText("");
                }
            }
        });

        //the decrypted text.
        decryptedTextLabel = new JLabel("Your decrypted text: ");
        decryptedTextField = new JTextField(100);
        decryptedTextLabel.setToolTipText("");

        //add the components.
        add(encryptedTextLabel);
        add(encryptedTextField);
        add(decryptionButton);
        add(decryptedTextLabel);
        add(decryptedTextField);

        //position the components and size them.
        //label and text field for encrypted text.
        encryptedTextLabel.setBounds(5, 0, 300, 30);
        encryptedTextField.setBounds( 5, 40,300, 50);
        //decryption button.
        decryptionButton.setBounds( 5, 260,300, 50);
        //the label and text field for the decrypted text.
        decryptedTextLabel.setBounds( 5, 320,300, 30);
        decryptedTextField.setBounds( 5, 360,300, 50);
    }

    /**
     * Formats the frame and sets basic functions
     */
    public static void main(String[] args) {
        BackdoorGUI frame = new BackdoorGUI();
        frame.setTitle("BackdoorGUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setBounds(200, 170, 800, 500);
        frame.setResizable(true);
    }
}