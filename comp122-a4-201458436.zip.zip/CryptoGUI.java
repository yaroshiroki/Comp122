/*

Name: Yaroslav Shiroki
Student ID: 201458436
University email address: Y.Shiroki@student.liverpool.ac.uk

*/
/**
 * @author Yaroslav Shiroki Y.Shiroki@student.liverpool.ac.uk

CryptoGUI class that uses the methods from the
Cipher interface.
 */
import javax.swing.*;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CryptoGUI extends JFrame {
    //Label to identify the text field for the plaintext.
    private JLabel plainTextLabel;
    //TextField where to input the plaintext.
    private final JTextField plainTextField;
    //Label to identify the text field for the key, by which we will shift the string.
    private JLabel intKeyLabel;
    //TextField where to input the key, by which we can shift the string of plaintext.
    private JTextField intKeyField;
    //Label to identify the text field for the shifted string.
    private JLabel outputLabel;
    //TextField where the shifted string will be output.
    private JTextField outputField;
    //Button to start the encryption of the string by key.
    private JButton encryptionButton;
    //Button to start the decryption of the string by key.
    private JButton decryptionButton;

    /**
     * Takes an integer and a text string as parameters and decrypts/encrypts the string by the shift by the required number of
     *  shifts based on the button press. Also formats most of the basic GUI functions for the frame and the layout of the frame.
     * @param intKeyTextField Input integer which corresponds to the amount we will shift the string by
     * @param plainTextField Input string to be shifted
     * @param encryptionButton click
     * @param decryptionButton click
     * @return Returns the rotated text string (outputField)
     * @return Returns error message if the intKeyField is not an integer
     */
    public CryptoGUI() {
        //turn off the default layout manager.
        setLayout(null);

        //create components.
        //plain text before encryption/decryption.
        plainTextLabel = new JLabel("Enter some text: ");
        plainTextField = new JTextField(100);
        plainTextField.setToolTipText("Enter some text here to encrypt or decrypt ");

        //the text field and corresponding label, responsible for the key integer in which we shift the text.
        intKeyLabel = new JLabel("Insert the key by which you want to shift the text: ");
        intKeyField = new JTextField(100);
        intKeyField.setToolTipText("Please insert an integer ");

        //buttons.
        //encryption button.
        encryptionButton = new JButton("Press to encrypt text");
        encryptionButton.setEnabled(true);
        encryptionButton.addActionListener(new ActionListener() {
            /**
             * Takes an integer shift key and a string text as parameters and rotates the string by the shift by the
             * required number of shifts when the button is pressed.
             * @param intKeyField Input integer which corresponds to the amount we will shift the string by
             * @param plainTextField Input string to be shifted
             * @param encryptionButton click
             * @return Returns the rotated text string (outputField)
             * @return Returns error message if the intKeyField is not an integer
             */
            public void actionPerformed(ActionEvent e) {
                try {
                    int key = Integer.parseInt(intKeyField.getText());
                    /**
                     * instantiating the Caesar class using  new Caesar(key)
                     */
                    Cipher c = new Caesar(key);
                    //encrypting the text using the Caesar class function.
                    String EncryptedText = c.encrypt(plainTextField.getText());
                    //output the text in required format.
                    outputField.setText("Encrypted text:  " + EncryptedText);
                }
                //parse the string intKeyField and if the input is not an integer, return an error message and reset the intKeyField.
                catch (NumberFormatException e1) {
                    JOptionPane.showMessageDialog(null, "Invalid input");
                    intKeyField.setText("");
                }
            }
        });

        //decryption button.
        decryptionButton = new JButton("Press to decrypt");
        decryptionButton.setEnabled(true);
        decryptionButton.addActionListener(new ActionListener() {
            /**
             * Takes an integer shift key and a string text as parameters and encrypts the string by the key by the
             * required number of shifts when the button is pressed.
             * @param intKeyField Input integer which corresponds to the amount we will shift the string by
             * @param plainTextField Input string to be shifted
             * @param decryptionButton click
             * @return Returns the rotated text string (outputField)
             * @return Returns error message if the intKeyField is not an integer
             */
            public void actionPerformed(ActionEvent e) {
                try {
                    int key = Integer.parseInt(intKeyField.getText());
                    /**
                     * instantiating the Caesar class using  new Caesar(key).
                     */
                    Cipher d = new Caesar(key);
                    //decrypting the text using the Caesar class function.
                    String EncryptedText = d.decrypt(plainTextField.getText());
                    //output the text in required format.
                    outputField.setText("Decrypted text:  " + EncryptedText);
                }
                //parse the string intKeyField and if the input is not an integer, return an error message and reset the intKeyField.
                catch (NumberFormatException e1) {
                    JOptionPane.showMessageDialog(null, "Invalid input");
                    intKeyField.setText("");
                }
            }
        });

        //the output text.
        outputLabel = new JLabel("Your encrypted / decrypted text: ");
        outputField = new JTextField(100);
        outputField.setToolTipText("");
        //add the components to the frame
        add(plainTextLabel);
        add(plainTextField);
        add(intKeyLabel);
        add(intKeyField);
        add(encryptionButton);
        add(decryptionButton);
        add(outputLabel);
        add(outputField);

        //position the components and size them.
        //label and text field for plain text.
        plainTextLabel.setBounds(5, 0, 300, 30);
        plainTextField.setBounds( 5, 40,300, 50);
        //label and text field for the integer box.
        intKeyLabel.setBounds( 5, 100,300, 30);
        intKeyField.setBounds( 5, 140,300, 50);
        //encryption and decryption button.
        encryptionButton.setBounds( 5, 200,300, 50);
        decryptionButton.setBounds( 5, 260,300, 50);
        //the label and text field for the outputted text.
        outputLabel.setBounds( 5, 320,300, 30);
        outputField.setBounds( 5, 360,300, 50);
    }

    /**
     * Formats the frame and sets basic functions
     */
    public static void main(String[] args) {
        CryptoGUI frame = new CryptoGUI();
        frame.setTitle("CryptoGUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setBounds(200, 170, 800, 500);
        frame.setResizable(true);
    }
}